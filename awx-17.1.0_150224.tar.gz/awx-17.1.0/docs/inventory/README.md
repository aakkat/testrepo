This folder contains documentation related to inventories in AWX / Ansible Tower.
