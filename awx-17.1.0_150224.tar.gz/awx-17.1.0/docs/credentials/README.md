This folder contains documentation related to credentials in AWX / Ansible Tower.
